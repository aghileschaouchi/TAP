/* 
***Variance****
toto(C <?extends T>
     D <?super T>)


*/

public class Jokers {

	public static void main(String[] args) {
		
		
	}
	
	}
	